import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner  scr = new Scanner(System.in);
        int a = scr.nextInt();
        int b = scr.nextInt();
        int summe = 0;
        for (int i =a; i<=b; i++) {
            if (i % 2 ==1) {
                summe +=i;
            }
        }
        System.out.println("suma neciotnich cisel v diapasone ot " + a + " do " + b + " ravna " + summe);
    }
}