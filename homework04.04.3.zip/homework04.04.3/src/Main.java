import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println(" Vvedite nazvannie meseata po angliiskii :");
        String mon = scr.nextLine();

        Month month1 = Month.valueOf(mon);
        System.out.println(" Ostalinie meseatza :");
        for (Month month : Month.values()) {
            if (month != month1){
                System.out.println(month.name()+ " ");
            }
        }
    }
}